using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ProjetoUC04_mo2.Models;
using Microsoft.AspNetCore.Http;
using System;

namespace ProjetoUC04_mo2.Controllers
{
    public class PacotesTuristicosController: Controller
    {

       /* public IActionResult Lista(){
             //desenvolver o corpo da acao da controller   
        }

        public IActionResult Remover(int Id){
            //desenvolver o corpo da acao da controller              
        }

        public IActionResult Editar(int Id){
            //desenvolver o corpo da acao da controller               
        }

        [HttpPost]
         public IActionResult Editar(PacotesTuristicos pac){
            //desenvolver o corpo da acao da controller   
         }
        */

        public IActionResult Cadastro(){
            return View(); 
        }

        /*[HttpPost]
         public IActionResult Cadastro(PacotesTuristicos pac){
            //desenvolver o corpo da acao da controller   
         }*/


    }
}
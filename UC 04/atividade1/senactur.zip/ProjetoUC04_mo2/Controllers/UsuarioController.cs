using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ProjetoUC04_mo2.Models;
using Microsoft.AspNetCore.Http;
using System;

namespace ProjetoUC04_mo2.Controllers
{
    public class UsuarioController: Controller
    {
        
        public IActionResult Login (){
            return View();
        }
        
        [HttpPost]
        public IActionResult Login(Usuario usuario){

            UsuarioRepository ur = new UsuarioRepository();
            Usuario user = ur.ValidarLogin(usuario);                

            if (user==null){
                ViewBag.Message = "Falha no login!";
                return View();
            } else {
                
                ViewBag.Message = "Você está logado";

                //vamos registrar na sessao minhas credenciais
                HttpContext.Session.SetInt32("IdUsuario",user.Id);
                HttpContext.Session.SetString("NomeUsuario",user.Nome);

                return View();
            }
        }
        
        public  IActionResult Logout(){
            HttpContext.Session.Clear();
            return View("Login");
        }   


        public IActionResult Lista(){
           
           //validacao = se nao tiver logado, chama a View de Login
           if (HttpContext.Session.GetInt32("IdUsuario")==null)
                return RedirectToAction("Login","Usuario");
           
            UsuarioRepository ur = new UsuarioRepository();
            List<Usuario> listagem = ur.Listar(); 
            return View(listagem);   
        }

        public IActionResult Remover(int Id){
           
           //validacao = se nao tiver logado, chama a View de Login
           if (HttpContext.Session.GetInt32("IdUsuario")==null)
                return RedirectToAction("Login","Usuario");
           
            UsuarioRepository ur = new UsuarioRepository();  
            Usuario userEncontrado = ur.BuscarPorID(Id);
            ur.Remover(userEncontrado);
            return RedirectToAction("Lista","Usuario"); 
        }

        public IActionResult Editar(int Id){
            
           //validacao = se nao tiver logado, chama a View de Login
           if (HttpContext.Session.GetInt32("IdUsuario")==null)
                return RedirectToAction("Login","Usuario");            
            
            UsuarioRepository ur = new UsuarioRepository();
            Usuario userEncontrado = ur.BuscarPorID(Id);
            return View(userEncontrado);
        }

        [HttpPost]
         public IActionResult Editar(Usuario usuario){
             UsuarioRepository ur = new UsuarioRepository();
             ur.Atualizar(usuario);
             return RedirectToAction("Lista","Usuario"); //acao,controller
         }


        public IActionResult Cadastro(){
          
            return View();
        }

        [HttpPost]
         public IActionResult Cadastro(Usuario usuario){
             UsuarioRepository ur = new UsuarioRepository();
             ur.Inserir(usuario);
             ViewBag.Mensagem = "Cadastro realizado com sucesso";
             return View();

         }


    }
}
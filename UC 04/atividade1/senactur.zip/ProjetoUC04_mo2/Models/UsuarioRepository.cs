using System;
using System.Collections.Generic;
using MySqlConnector;

namespace ProjetoUC04_mo2.Models
{
    public class UsuarioRepository
    {

        //qual a finalidade da classe UsuarioRepository:
        //termos as operações de manipulação de dados da classe Usuario
        //abrir uma conexao com o banco de dados
        //operacoes: cadastrar, listar , editar, deletar  - CRUD

        private const string DadosConexao = "Database=SenacTur;Data Source=localhost;User Id=root;";    
        
        public void TestarConexao(){

            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();
            Console.WriteLine("Banco de dados funcionando corretamente");
            Conexao.Close();
        }    


        public Usuario ValidarLogin(Usuario user){

            //abrir a conexao
            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();

            //sql de consulta por login e senha
            String SqlConsultaLoginSenha = "select * from Usuario WHERE Login=@Login and Senha=@Senha"; 

            //prepara o comando (SqlConsultaId + Conexao - local do banco de dados)
            MySqlCommand Comando = new MySqlCommand(SqlConsultaLoginSenha,Conexao);
            
            //tratamento para sql injection
            Comando.Parameters.AddWithValue("@Login",user.Login);
            Comando.Parameters.AddWithValue("@Senha",user.Senha);
            
            MySqlDataReader Reader = Comando.ExecuteReader(); //executar o comando

            //vamos inicializar o objeto userEncontrado com 'null'
            //caso nao retone um usuario encontrado no banco de dados ele sera 'null'
            Usuario userEncontrado = null; 
            
            //caso encontre o usuario pelo objeto "Reader", ele irá atribuir os dados do banco de dados
            if (Reader.Read()) {
            
                userEncontrado = new Usuario();
                userEncontrado.Id = Reader.GetInt32("Id");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Nome")))
                    userEncontrado.Nome = Reader.GetString("Nome");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Login")))
                    userEncontrado.Login = Reader.GetString("Login");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Senha")))
                    userEncontrado.Senha = Reader.GetString("Senha");

                userEncontrado.DataNascimento = Reader.GetDateTime("DataNascimento");

            }

            //fechar a conexao
             Conexao.Close();

            //retornar a lista
            return userEncontrado;

        }


        public void Inserir(Usuario user){
            
            //abrir a conexao 
            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();

            //sql de inclusao
            String SqlInclusao = "insert into Usuario (Nome,Login,Senha,DataNascimento) VALUES (@Nome,@Login,@Senha,@DataNascimento)";

            //prepara o comando (SqlInclusao + Conexao - local do banco de dados)
             MySqlCommand Comando = new MySqlCommand(SqlInclusao,Conexao);

            //tratamento para sql injection
             Comando.Parameters.AddWithValue("@Nome",user.Nome);
             Comando.Parameters.AddWithValue("@Login",user.Login);
             Comando.Parameters.AddWithValue("@Senha",user.Senha);
             Comando.Parameters.AddWithValue("@DataNascimento",user.DataNascimento);

            //execucao no banco de dados
            Comando.ExecuteNonQuery();

            //fechar a conexao
            Conexao.Close();
        }

        public void Atualizar(Usuario user){
            
            //abrir a conexao 
            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();

            //sql de atualizacao
            String SqlAtualizacao = "update Usuario SET Nome=@Nome, Login=@Login, Senha=@Senha, DataNascimento=@DataNascimento WHERE Id=@Id";

            //prepara o comando (o que tem nele? SqlAtualizacao + Conexao - local do banco de dados)
             MySqlCommand Comando = new MySqlCommand(SqlAtualizacao,Conexao);

            //tratamento para sql injection
             Comando.Parameters.AddWithValue("@Id",user.Id);
             Comando.Parameters.AddWithValue("@Nome",user.Nome);
             Comando.Parameters.AddWithValue("@Login",user.Login);
             Comando.Parameters.AddWithValue("@Senha",user.Senha);
             Comando.Parameters.AddWithValue("@DataNascimento",user.DataNascimento);

            //execucao no banco de dados
            Comando.ExecuteNonQuery();

            //fechar a conexao
            Conexao.Close();
        }


        public void Remover(Usuario user){

            //abrir a conexao    
            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();

            //sql de exclusao
            String SqlExclusao = "delete from Usuario WHERE Id=@Id"; 

            //prepara o comando (o que tem nele? sqlExclusao + Conexao - local do banco de dados)
            MySqlCommand Comando = new MySqlCommand(SqlExclusao,Conexao);

            //tratamento para sql injection
            Comando.Parameters.AddWithValue("@Id",user.Id);

            //execucao no banco de dados
            Comando.ExecuteNonQuery();

            //fechar a conexao
             Conexao.Close();
        }


        public List<Usuario> Listar(){

            //abrir a conexao
            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();

            //sql de consulta
            String SqlConsulta = "select * from Usuario"; 

            //prepara o comando (o que tem nele? sqlConsulta + Conexao - local do banco de dados)
            MySqlCommand Comando = new MySqlCommand(SqlConsulta,Conexao);
            MySqlDataReader Reader = Comando.ExecuteReader(); //executar o comando

            //criar a lista de Usuarios do banco de dados    
            List<Usuario> lista = new List<Usuario>();

            //percorrer os registros que foram executados em 'Reader'
            while(Reader.Read()){

                //alimentar o objeto 'user' com informacoes do Reader
                Usuario user = new Usuario();
                user.Id = Reader.GetInt32("Id");
               
                if (!Reader.IsDBNull(Reader.GetOrdinal("Nome")))
                    user.Nome = Reader.GetString("Nome");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Login")))
                    user.Login = Reader.GetString("Login");

                if (!Reader.IsDBNull(Reader.GetOrdinal("Senha")))
                    user.Senha = Reader.GetString("Senha");
                
                user.DataNascimento =  Reader.GetDateTime("DataNascimento"); 
                
                //adicionar na lista o objeto 'user' item a item de acordo com o percurso
                lista.Add(user);
            }

            //fechar a conexao
             Conexao.Close();

            //retornar a lista
            return lista;

        }


        public Usuario BuscarPorID(int Id){

            //abrir a conexao
            MySqlConnection Conexao = new MySqlConnection(DadosConexao);
            Conexao.Open();

            //sql de consulta por Id
            String SqlConsultaId = "select * from Usuario WHERE Id=@Id"; 

            //prepara o comando (SqlConsultaId + Conexao - local do banco de dados)
            MySqlCommand Comando = new MySqlCommand(SqlConsultaId,Conexao);
            
            //tratamento para sql injection
            Comando.Parameters.AddWithValue("@Id",Id);
            
            MySqlDataReader Reader = Comando.ExecuteReader(); //executar o comando

            Usuario userEncontrado = new Usuario();

            if (Reader.Read()) {
            
                userEncontrado.Id = Reader.GetInt32("Id");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Nome")))
                    userEncontrado.Nome = Reader.GetString("Nome");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Login")))
                    userEncontrado.Login = Reader.GetString("Login");
                
                if (!Reader.IsDBNull(Reader.GetOrdinal("Senha")))
                    userEncontrado.Senha = Reader.GetString("Senha");

                userEncontrado.DataNascimento = Reader.GetDateTime("DataNascimento");

            }

            //fechar a conexao
             Conexao.Close();

            //retornar a lista
            return userEncontrado;

        }        



    }
}
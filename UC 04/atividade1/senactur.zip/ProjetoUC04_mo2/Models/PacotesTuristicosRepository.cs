namespace ProjetoUC04_mo2.Models
{
    public class PacotesTuristicosRepository
    {

        private const string DadosConexao = "Database=SenacTur;Data Source=localhost;User Id=root;";    

        //TODO O CRUD
        /*public void Inserir(PacotesTuristicos pac){
            //desenvolver seu metodo
        }    

        public void Atualizar(PacotesTuristicos pac){
            //desenvolver seu metodo
        }

        public void Remover(PacotesTuristicos pac){
            //desenvolver seu metodo
        }

        public List<PacotesTuristicos> Listar(){
            //desenvolver seu metodo
        }    

        public PacotesTuristicos BuscarPorID(int Id){
            //desenvolver seu metodo
        }*/        

    }
}